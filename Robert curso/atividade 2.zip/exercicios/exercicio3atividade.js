var angulo = parseInt(prompt("Digite o primeiro angulo"))
var angulo2 = parseInt(prompt("Digite o segundo angulo"))
var angulo3 = parseInt(prompt("Digite o terceiro angulo"))

if(angulo == 90 || angulo2 == 90 || angulo3 == 90){
 alert("Esse triângulo  é um Retângulo")
}if(angulo > 90 || angulo2 > 90 || angulo3 > 90){
    alert("Esse triângulo  é um obtusângulo")
}if(angulo < 90 || angulo2 < 90 || angulo3 < 90){
    alert("Esse triângulo  é um acutângulo")
}else if (angulo == null || angulo2 == null || angulo3 == null){
    alert("numero invalido")
}