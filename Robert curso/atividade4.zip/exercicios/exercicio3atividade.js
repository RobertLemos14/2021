var numero = parseInt(prompt("Digite um numero: "))

var quadrado = numero * numero

alert(quadrado)