var polegadasDeChuva = parseInt(prompt("Digite aqui a quantidade de chuva em polgedas"))

var mm = polegadasDeChuva * 25.4

alert("Essa é a quantidade de chuva em milimetros: " + mm)
