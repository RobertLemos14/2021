var numero1 = 5
var numero2 = 40 
var numero3 = 20
var numero4 = 10

media = numero1 * numero3 - numero4 + numero2

alert(media)