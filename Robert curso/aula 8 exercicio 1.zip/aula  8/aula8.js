function cronometro(){
    var milesimodesegundo
    var segundo
    var minuto
    var hora
    for (let i  = 0; i  < array.length; i ++) {
        milesimodesegundo++
        if(milesimodesegundo == 100){
            segundo++
            milesimodesegundo = 0
        } if(segundo == 60){
            minuto++
            segundo = 0
        } if(minuto == 100){
            hora++
            minuto = 0
        }
    }
}