var grausCelsius = prompt("digite aqui os graus Celsius")

var Fahrenheit = 9/5 * grausCelsius + 32
document.write("esse é o valor em Fahrenheit: " + Fahrenheit)